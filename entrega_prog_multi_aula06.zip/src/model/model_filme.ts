/**
 *  Nome: Jônatas Ferreira de Oliveira RA: 818231518
 */

export interface Filme {
    nome: string;
    descricao: string;
}

export interface Genero {
    nome: string;
    genero: string;
}